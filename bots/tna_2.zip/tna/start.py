from controller import Controller, create_need_tickets
import asyncio

async def main():
    create_need_tickets()#cоздание структуры билетов необходимых для откупки
    worker = Controller('https://tna-tickets.ru/tickets/booking?id=14758')
    res = await worker.main()

asyncio.run(main())

 